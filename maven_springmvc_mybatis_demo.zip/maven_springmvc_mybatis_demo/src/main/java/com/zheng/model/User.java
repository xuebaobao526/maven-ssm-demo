package com.zheng.model;

public class User {
	private Integer userId;  
    private String userName;  
    private String userPassword;
    /*
    by lyx
    2018.6.28
     */
    public User() {
        super();
    }
    public User(String userName, String userPassword) {
        super();
        this.userName = userName;
        this.userPassword = userPassword;
    }

    public Integer getUserId() {  
        return userId;  
    }  
  
    public void setUserId(Integer userId) {  
        this.userId = userId;  
    }  
  
    public String getUserName() {  
        return userName;  
    }  
  
    public void setUserName(String userName) {  
      //  this.userName = userName;
        this.userName = userName == null ? null : userName.trim(); //除了单词中的空格外，清楚文本中的所有空格
    }  
  
    public String getUserPassword() {  
        return userPassword;  
    }  
  
    public void setUserPassword(String userPassword) {  
        this.userPassword = userPassword;  
    }

    public String toString() {
        return "[id=" + userId + ", username=" + userName + ", password=" + userPassword + "]";
    }

}
