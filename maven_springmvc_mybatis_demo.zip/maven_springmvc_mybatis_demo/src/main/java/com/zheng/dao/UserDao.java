package com.zheng.dao;

import com.zheng.model.PageBean;
import com.zheng.model.User;

import java.util.HashMap;
import java.util.List;

public interface UserDao {
	User selectUserById(Integer userId);

	//lyx 2018.6.27
	User selectUserByName(String name);

	//lyx 2018.6.28
	User loginByUserNameAndPassword(User record);
	int selectCount(); //查询的记录总数
	List<User> selectUserList(); //查询出的用户列表
	List<User> findByPage(HashMap<String, Object> map); //规定页面中的所有用户

	//lyx 2018.6.29
	int insertUser(User record);
	int updateUserById(User record);
	int deleteById(int userId);
}
