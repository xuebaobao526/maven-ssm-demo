package com.zheng.controller;

import javax.annotation.Resource;
import javax.jws.WebParam;

import com.zheng.dao.UserDao;
import com.zheng.model.PageBean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.zheng.model.User;
import com.zheng.service.UserService;

import java.util.Iterator;
import java.util.List;

//@SessionAttributes("currentUser")
@Controller
public class UserController {
	
    @Resource  
    private UserService userService;

    /*@RequestMapping("/showUserInfo")
    public ModelAndView getIndex(){
        ModelAndView mav = new ModelAndView("index");   
        User user = userService.selectUserById(1);  
        mav.addObject("user", user);   
        return mav;    
    } */

    /*by lyx
    2018.6.27
     */
/*
    //功能一：通过提交表单，在页面显示提交的数据，不涉及数据库操作
    @RequestMapping("submit")
    public ModelAndView test1() {
        ModelAndView mav = new ModelAndView("login");
        return mav;
    }
    @RequestMapping("login")
    public ModelAndView test3(@RequestParam("userName") String userName, @RequestParam("userPassword") String userPassword) {
     //   System.out.println(userName);
     //   System.out.println(userPassword);
        ModelAndView mav = new ModelAndView("show");
        mav.addObject("userName",userName);
        mav.addObject("userPassword", userPassword);
        return mav;
    }

    //功能二：页面输入查询（姓名），返回从数据库中查出的详细结果，不能处理同一姓名有多个人对应的情况
    @RequestMapping("select")  //访问时的地址
    public ModelAndView find1() {
        ModelAndView mav = new ModelAndView("input");  //该地址直接定位到input页面
        return mav;
    }
    //接收input页面传进来的参数，返回到output页面
    @RequestMapping("input")
    public ModelAndView find2(@RequestParam("s_name") String s_name) {
       // System.out.println(s_name);
        ModelAndView mav = new ModelAndView("output");
        User user = userService.selectUserByName(s_name);
        mav.addObject("user",user);
        return mav;
    }
*/
    //by lyx 2018.6.28
    //功能三：查询数据并实现分页功能
    /*@RequestMapping("/truelogin")
    public ModelAndView test11() {
        ModelAndView mav = new ModelAndView("denglu");
        return mav;
    }
    //接受login1传来的参数
    @RequestMapping("/denglu")  //登录成功，分页显示所有用户列表
    public String login(@RequestParam("userName") String name, @RequestParam("userPassword") String pass, Model model) throws Exception{
        User user = new User();
        user.setUserName(name);
        user.setUserPassword(pass);

        User userResult = userService.loginByUserNameAndPassword(user);

        if(userResult!=null){ //登录成功
            List<User> lists = userService.selectUserList();
           // System.out.println(lists.size());
            Iterator<User> ite = lists.iterator();
            while(ite.hasNext()) {
                User uuser = ite.next();
                System.out.println(uuser.toString());
           }
            model.addAttribute("userLists", lists);//回显用户信息
            model.addAttribute("currentUser", userResult.getUserName());
            return "redirect:main";
        }
        return "error";
    }
    @RequestMapping("/main")
    public String  main(@RequestParam(value="currentPage",defaultValue="1",required=false)int currentPage,Model model){
        PageBean pageBean = userService.findByPage(currentPage);
        model.addAttribute("pagemsg",pageBean); //回显分页数据
        return "main";
   }*/

  //by lyx 2018.6.29
    //功能四：分页展示结果，添加增删改功能，页面上需要显示对应链接
    @RequestMapping("/main")
    public String select(@RequestParam(value="currentPage",defaultValue="1",required = false)int currentPage, Model model) {
        PageBean pageBean = userService.findByPage(currentPage);
        model.addAttribute("pagemsg",pageBean);
        return "main";
    }
    //编辑页面，增加修改都需要跳到此页面
    @RequestMapping("/edit")
    public String edit(@RequestParam("userId") int userId, Model model) {
        User record = userService.selectUserById(userId);
        System.out.println("我是edit" + record.toString());
        model.addAttribute("returnUser",record);
        return "edit";
    }
    //页面进行edit之后需要保存
    @RequestMapping("/save")
    public String save(User record) {
        System.out.println(record.toString());
        if (record.getUserId() == null) {//记录中没有id，证明进行保存操作(增加)
            userService.insertUser(record);
        }
        else {
            userService.updateUserById(record); //记录中有id，证明进行的操作是修改
        }
        return "redirect:main";
    }
    //增加一个用户
    @RequestMapping("/add")
    public String add(Model model) {
        model.addAttribute("returnUser", new User()); //在returnUser里面传入一个空的User对象
        return "edit";
    }
    @RequestMapping("/delete")
    public String delete(@RequestParam("userId") int userId) {
        userService.deleteById(userId);
        return "redirect:main";
    }
}
