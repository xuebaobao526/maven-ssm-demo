package com.zheng.service;

import com.zheng.model.PageBean;
import com.zheng.model.User;

import java.util.List;

public interface UserService {
	User selectUserById(Integer userId);

	/*by lyx 2018.6.27 */
	User selectUserByName(String name); //按姓名查找用户信息

	//lyx 2018.6.28
	User loginByUserNameAndPassword(User record);
	int selectCount();
	List<User> selectUserList();
	PageBean<User> findByPage(int currentPage);

	//lyx 2018.6.29
	int insertUser(User record);
	int updateUserById(User record);
	int deleteById(int userId);
}


