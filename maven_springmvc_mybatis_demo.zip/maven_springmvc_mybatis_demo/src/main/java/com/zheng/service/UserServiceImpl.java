package com.zheng.service;

import com.zheng.model.PageBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zheng.dao.UserDao;
import com.zheng.model.User;

import java.util.HashMap;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {
	@Autowired  
    private UserDao userDao;  
  
    public User selectUserById(Integer userId) {  
        return userDao.selectUserById(userId);  
          
    }
    /*by lyx 2018.6.27*/
    public  User selectUserByName(String userName) {
        return userDao.selectUserByName(userName);
    }

    //by lyx 2018.6.28
    public User loginByUserNameAndPassword(User record) {
        return userDao.loginByUserNameAndPassword(record);
    }
    //所有用户数
    public int selectCount() {
        return userDao.selectCount();
    }
    //查出所有的用户
    public List<User> selectUserList() {
        return userDao.selectUserList();
    }

    public PageBean<User> findByPage(int currentPage) {
        HashMap<String, Object> map = new HashMap<String, Object>(); //map中存储对应的起始页和每页大小 start和size
        PageBean<User> pageBean = new PageBean<User>();
        //封装当前页数
        pageBean.setCurrPage(currentPage);

        //每页显示的数据
        int pageSize = 2;
        pageBean.setPageSize(pageSize);

        //封装总记录数
        int totalCount = userDao.selectCount();
        pageBean.setTotalCount(totalCount);

        //封装总页数
        double tc = totalCount;
        Double num = Math.ceil(tc / pageSize);//向上取整
        pageBean.setTotalPage(num.intValue());

        map.put("start", (currentPage - 1) * pageSize);
        map.put("size", pageBean.getPageSize());

        //封装每页显示的数据
        List<User> lists = userDao.findByPage(map); //规定页面中的所有用户
        pageBean.setLists(lists); //每页需显示的所有用户

        return pageBean;
    }
    //lyx 2018.6.29
    public int insertUser(User record) {
        return userDao.insertUser(record);
    }
    public int updateUserById(User record){
        return userDao.updateUserById(record);
    }
    public int deleteById(int userId) {
        return userDao.deleteById(userId);
    }
}
